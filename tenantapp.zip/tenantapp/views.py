from django.shortcuts import render,redirect
from django.http import HttpResponse
from ownerapp.models import Room
def index(request):
 if(request.session.has_key('uname')):
 	u = request.session["uname"]
 	return render(request,"tenantapp/index.html",{"res":u})
 else:
    return redirect('/guestapp/tlogin') 	

def logout(request):
	del request.session["uname"]
	return redirect('/guestapp/tlogin')

def searchroom(request):
   return render(request,"tenantapp/searchroom.html")

def searchresult(request):
	 data = request.GET["q"]
	 result = Room.objects.filter(rdetails__contains=data)
	 return render(request,"tenantapp/searchresult.html",{'res':result})   	
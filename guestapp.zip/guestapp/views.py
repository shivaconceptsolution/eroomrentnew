from django.shortcuts import render,redirect
from .models import Reg,Owner
from django.http import HttpResponse
def index(request):
	if request.method=="POST":
		obj = Reg(uname=request.POST["txtuname"],upass=request.POST["txtupass"],uemail=request.POST["txtuemail"],umobile=request.POST["txtumobile"])
		obj.save()
		return render(request,"guestapp/index.html",{'res':'data inserted sucessfully'})


	return render(request,"guestapp/index.html")

def tlogin(request):
	if request.method=="POST":
		r = Reg.objects.filter(uname=request.POST["txtuname"],upass=request.POST["txtupass"])
		if r.count()>0:
			request.session["uname"]=request.POST["txtuname"]
			return redirect('/tenantapp')
		else:
		    return render(request,"guestapp/tlogin.html",{'res':'invalid userid and password'})	
	return render(request,"guestapp/tlogin.html")
def showreg(request):
	r = Reg.objects.all() # select * from reg
	return render(request,"guestapp/showreg.html",{'key':r})


def owner(request):
	if request.method=="POST":
		obj = Owner(email=request.POST["txtuemail"],password=request.POST["txtupass"],fname=request.POST["txtuname"],mobile=request.POST["txtumobile"])
		obj.save()
		return render(request,"guestapp/owner.html",{'res':'data inserted sucessfully'})
	return render(request,"guestapp/owner.html")


def login(request):
	if request.method=="POST":
		s =  Reg.objects.filter(uname=request.POST["txtuid"],upass=request.POST["txtpass"])
		if s.count()>0:
			request.session["sessuid"]=request.POST["txtuid"]
			return redirect("/userapp")
		else:
		   return render(request,"guestapp/login.html",{"res":"login not successfully"})	

	return render(request,"guestapp/login.html")

#update

def findrec(request):
	s = Reg.objects.get(pk=int(request.GET["q"])) # select * from Reg where id=?
	return render(request,"guestapp/findrec.html",{'res':s})	

def editrec(request):
	r = Reg.objects.get(pk=int(request.POST["txtid"]))
	r.uname= request.POST["txtuname"]
	r.upass= request.POST["txtupass"]
	r.uemail = request.POST["txtuemail"]
	r.umobile = request.POST["txtumobile"]
	r.save()
	return redirect('showreg')

#delete

def findrec1(request):
	s = Reg.objects.get(pk=int(request.GET["q"])) # select * from Reg where id=?
	return render(request,"guestapp/findrec1.html",{'res':s})

def deleterec(request):
  	s = Reg.objects.get(pk=int(request.POST["txtid"]))
  	s.delete()
  	return redirect('showreg')	

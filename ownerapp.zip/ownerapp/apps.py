from django.apps import AppConfig


class OwnerappConfig(AppConfig):
    name = 'ownerapp'

from django.db import models
class Room(models.Model):
	filepath = models.CharField(max_length=100)
	rdetails = models.CharField(max_length=100)

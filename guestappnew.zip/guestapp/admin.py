from django.contrib import admin
from .models import Reg,Owner

admin.site.register(Reg)
admin.site.register(Owner)

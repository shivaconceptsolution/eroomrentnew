from django.urls import path
from . import views

urlpatterns=[
path('',views.index,name='index'),
path('searchroom',views.searchroom,name='searchroom'),
path('searchresult',views.searchresult,name='searchresult'),
path('logout',views.logout,name='logout')

]
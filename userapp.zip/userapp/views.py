from django.shortcuts import render,redirect
from guestapp.models import Reg
def index(request):
 if(request.session.has_key('sessuid')):	
   sess = request.session["sessuid"]
   obj = Reg.objects.get(uname=sess)	
   return render(request,"userapp/index.html",{'key':obj})
 else:
    return redirect('/guestapp/login')
def editprofile(request):
	r = Reg.objects.get(pk=int(request.POST["txtid"]))
	r.uname = request.POST["txtuname"]
	r.upass = request.POST["txtpass"]
	r.uemail = request.POST["txtemail"]
	r.umobile = request.POST["txtmobile"]
	r.save()
	return redirect('/userapp')

def about(request):
 return render(request,"userapp/about.html")
def services(request):
 return render(request,"userapp/services.html")
def contact(request):
 return render(request,"userapp/contact.html")
def logout(request):
 del request.session['sessuid']	
 return redirect('/guestapp/login')

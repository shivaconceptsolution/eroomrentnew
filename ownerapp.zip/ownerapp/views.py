from django.shortcuts import render
from django.http import HttpResponse
from django.core.files.storage import FileSystemStorage
from .models import Room
def index(request):
	obj = Room.objects.all()
	return render(request,"ownerapp/index.html",{"res":obj})
def about(request):
	return HttpResponse("<h1>Welcome in About us page</h1>")

def addroom(request):
	if request.method=="POST":
		f = request.FILES["myfile"]
		obj = FileSystemStorage()
		fname=obj.save(f.name,f)
		rdet = request.POST["txtdetails"]
		room = Room(filepath=f.name,rdetails=rdet)
		room.save()
		return render(request,"ownerapp/addroom.html",{"res":obj.url(fname)})
	return render(request,"ownerapp/addroom.html")

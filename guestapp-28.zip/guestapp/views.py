from django.shortcuts import render,redirect
from .models import Reg,Owner,Feedback
from django.http import HttpResponse
def index(request):
	if request.method=="POST":
		obj = Reg(uname=request.POST["txtuname"],upass=request.POST["txtupass"],uemail=request.POST["txtuemail"],umobile=request.POST["txtumobile"])
		obj.save()
		return render(request,"guestapp/index.html",{'res':'data inserted sucessfully'})


	return render(request,"guestapp/index.html")

def tlogin(request):
	if request.method=="POST":
		r = Reg.objects.filter(uname=request.POST["txtuname"],upass=request.POST["txtupass"])
		if r.count()>0:
			request.session["uname"]=request.POST["txtuname"]
			return redirect('/tenantapp')
		else:
		    return render(request,"guestapp/tlogin.html",{'res':'invalid userid and password'})	
	return render(request,"guestapp/tlogin.html")
def showreg(request):
	r = Reg.objects.all() # select * from reg
	return render(request,"guestapp/showreg.html",{'key':r})


def owner(request):
	if request.method=="POST":
		obj = Owner(email=request.POST["txtuemail"],password=request.POST["txtupass"],fname=request.POST["txtuname"],mobile=request.POST["txtumobile"])
		obj.save()
		return render(request,"guestapp/owner.html",{'res':'data inserted sucessfully'})
	return render(request,"guestapp/owner.html")


def login(request):
	if request.method=="POST":
		s =  Reg.objects.filter(uname=request.POST["txtuid"],upass=request.POST["txtpass"])
		if s.count()>0:
			request.session["sessuid"]=request.POST["txtuid"]
			return redirect("/userapp")
		else:
		   return render(request,"guestapp/login.html",{"res":"login not successfully"})	

	return render(request,"guestapp/login.html")

#update

def findrec(request):
	s = Reg.objects.get(pk=int(request.GET["q"])) # select * from Reg where id=?
	return render(request,"guestapp/findrec.html",{'res':s})	

def editrec(request):
	r = Reg.objects.get(pk=int(request.POST["txtid"]))
	r.uname= request.POST["txtuname"]
	r.upass= request.POST["txtupass"]
	r.uemail = request.POST["txtuemail"]
	r.umobile = request.POST["txtumobile"]
	r.save()
	return redirect('showreg')

#delete

def findrec1(request):
	s = Reg.objects.get(pk=int(request.GET["q"])) # select * from Reg where id=?
	return render(request,"guestapp/findrec1.html",{'res':s})

def deleterec(request):
  	s = Reg.objects.get(pk=int(request.POST["txtid"]))
  	s.delete()
  	return redirect('showreg')	


def feedback(request):
	if request.method=="POST":
		name = request.POST["txtname"]
		user = request.POST.getlist("chk1[]")
		u=''
		for data in user:
			u = u + data
		feed = request.POST["feed"]
		c = request.POST['city']
		m = request.POST.getlist('mcity[]')
		m1=''
		for data in m:
			m1=m1+data+' '
		obj = Feedback(fname=name,utype=u,feed=feed,cityname=c,mcity=m1)
		obj.save()
		
		return render(request,"guestapp/feedback.html",{'res':Feedback.objects.all()})
	else:
		return render(request,"guestapp/feedback.html",{'res':Feedback.objects.all()})     


def editfeed(request):
	r = Feedback.objects.get(pk=request.GET["q"])
	m = r.mcity
	data = list(m.split(" "))
	data1=data[0:len(data)-1]
	#return HttpResponse(data)
	return render(request,"guestapp/editfeed.html",{'res':r,'lst':data1})


def updatefeed(request):
	r = Feedback.objects.get(pk=request.POST["txtid"])
	r.fname = request.POST["txtname"]
	user = request.POST.getlist("chk1[]")
	u=''
	for data in user:
		u = u + data
	r.utype = u
	r.feed = request.POST["feed"]
	r.cityname = request.POST['city']
	m = request.POST.getlist('mcity[]')
	m1=''
	for data in m:
		m1=m1+data+' '
	r.mcity=m1
	r.save()
	return redirect('feedback')		
